import type { Context, Config } from "@netlify/functions";
import { getStore, getDeployStore } from "@netlify/blobs";

function getBlobStore() {
  if (Netlify.context?.deploy?.context === "production") {
    return getStore("applications");
  }
  return getDeployStore("applications");
}

export default async (req: Request, context: Context) => {
  const url = new URL(req.url);
  const id = url.searchParams.get("id")?.trim();
  const email = url.searchParams.get("email")?.trim().toLowerCase();

  if (!id || !email) {
    return new Response(JSON.stringify({ error: "Missing id or email" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const store = getBlobStore();
  const record = await store.get(id, { type: "json" });

  if (!record || record.email !== email) {
    return new Response(JSON.stringify({ found: false }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  }

  return new Response(
    JSON.stringify({
      found: true,
      status: record.status,
      submittedAt: record.submittedAt,
    }),
    { status: 200, headers: { "Content-Type": "application/json" } }
  );
};

export const config: Config = {
  path: "/api/check-status",
};
