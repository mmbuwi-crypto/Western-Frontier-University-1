import type { Context, Config } from "@netlify/functions";
import { getStore, getDeployStore } from "@netlify/blobs";

function getBlobStore() {
  if (Netlify.context?.deploy?.context === "production") {
    return getStore("applications");
  }
  return getDeployStore("applications");
}

const ALLOWED_STATUSES = [
  "submitted",
  "payment_verified",
  "under_review",
  "awarded",
  "not_selected",
];

export default async (req: Request, context: Context) => {
  const adminPassword = Netlify.env.get("ADMIN_PASSWORD");

  if (!adminPassword) {
    return new Response(JSON.stringify({ error: "Admin access is not configured yet." }), {
      status: 503,
      headers: { "Content-Type": "application/json" },
    });
  }

  const suppliedPassword = req.headers.get("x-admin-password");
  if (suppliedPassword !== adminPassword) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  let body: { applicationId?: string; status?: string };
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const { applicationId, status } = body;

  if (!applicationId || !status || !ALLOWED_STATUSES.includes(status)) {
    return new Response(JSON.stringify({ error: "Missing or invalid applicationId/status" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const store = getBlobStore();
  const existing = await store.get(applicationId, { type: "json" });

  if (!existing) {
    return new Response(JSON.stringify({ error: "Application not found" }), {
      status: 404,
      headers: { "Content-Type": "application/json" },
    });
  }

  const updated = { ...existing, status, updatedAt: new Date().toISOString() };
  await store.setJSON(applicationId, updated);

  return new Response(JSON.stringify({ ok: true, application: { id: applicationId, ...updated } }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
};

export const config: Config = {
  path: "/api/update-status",
};
