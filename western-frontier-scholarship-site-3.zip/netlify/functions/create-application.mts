import type { Context, Config } from "@netlify/functions";
import { getStore, getDeployStore } from "@netlify/blobs";

function getBlobStore() {
  if (Netlify.context?.deploy?.context === "production") {
    return getStore("applications");
  }
  return getDeployStore("applications");
}

export default async (req: Request, context: Context) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  let body: { applicationId?: string; email?: string; fullName?: string };
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const { applicationId, email, fullName } = body;

  if (!applicationId || !email) {
    return new Response(JSON.stringify({ error: "Missing applicationId or email" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  const store = getBlobStore();
  await store.setJSON(applicationId, {
    email: email.toLowerCase().trim(),
    fullName: fullName || "",
    status: "submitted",
    submittedAt: new Date().toISOString(),
  });

  return new Response(JSON.stringify({ ok: true }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
};

export const config: Config = {
  path: "/api/create-application",
};
