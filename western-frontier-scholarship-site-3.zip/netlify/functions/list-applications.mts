import type { Context, Config } from "@netlify/functions";
import { getStore, getDeployStore } from "@netlify/blobs";

function getBlobStore() {
  if (Netlify.context?.deploy?.context === "production") {
    return getStore("applications");
  }
  return getDeployStore("applications");
}

export default async (req: Request, context: Context) => {
  const adminPassword = Netlify.env.get("ADMIN_PASSWORD");

  if (!adminPassword) {
    return new Response(JSON.stringify({ error: "Admin access is not configured yet." }), {
      status: 503,
      headers: { "Content-Type": "application/json" },
    });
  }

  const suppliedPassword = req.headers.get("x-admin-password");
  if (suppliedPassword !== adminPassword) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  const store = getBlobStore();
  const { blobs } = await store.list();

  const applications = await Promise.all(
    blobs.map(async ({ key }) => {
      const record = await store.get(key, { type: "json" });
      return { id: key, ...record };
    })
  );

  applications.sort((a, b) => {
    const aDate = a.submittedAt ? new Date(a.submittedAt).getTime() : 0;
    const bDate = b.submittedAt ? new Date(b.submittedAt).getTime() : 0;
    return bDate - aDate;
  });

  return new Response(JSON.stringify({ applications }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
};

export const config: Config = {
  path: "/api/list-applications",
};
